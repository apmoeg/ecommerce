class LabelAsModel{
  String title;
  String icon;
  LabelAsModel(this.title, this.icon);
}