enum  FromPage{
  forgetPassword,
  digitalProduct,
  verification,
  profile,
  login,
  otpLogin,
  signUp
}