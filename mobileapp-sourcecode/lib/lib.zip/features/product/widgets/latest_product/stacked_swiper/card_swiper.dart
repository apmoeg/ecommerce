/// This library is for swiper
library card_swiper;

export 'flutter_page_indicator/flutter_page_indicator.dart';
export 'swiper.dart';
export 'swiper_control.dart';
export 'swiper_controller.dart';
export 'swiper_pagination.dart';
export 'swiper_plugin.dart';
export 'transformer_page_view/index_controller.dart';
