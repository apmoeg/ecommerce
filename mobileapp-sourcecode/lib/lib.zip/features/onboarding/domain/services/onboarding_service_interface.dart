abstract class OnBoardingServiceInterface{

  Future<dynamic> getList({int? offset = 1});
}