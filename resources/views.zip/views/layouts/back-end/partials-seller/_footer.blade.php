
<div class="footer">
    <div class="row justify-content-between align-items-center">
        <div class="col mt-3">
            <p class="font-size-sm mb-0 title-color text-center text-lg-left">
                {{ getWebConfig(name: 'company_name').'.' }}
                <span class="d-none d-sm-inline-block">{{ getWebConfig('company_copyright_text') }}</span>
            </p>
        </div>
    </div>
</div>
